Vue.component('counter', {
  template: '<button v-on:click="countDownTimer()">{{ countDown }}</button>',
  data: function () {
      return {
          countDown: 30,
          countDownTimer() {
              if (this.countDown > 0) {
                  setTimeout(() => {
                      this.countDown -= 1
                      this.countDownTimer();
                  }, 1000)
              }
          }
      }
  }
})

const app = new Vue({
  el: '#app'
})